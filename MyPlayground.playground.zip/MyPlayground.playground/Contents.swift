import Cocoa

class Vehicul {
    var culoare: String = "Negru"
    var numarLocuri: Int
    
    private(set) var marca: String
    private(set) var anFabricatie: Int
    private(set) var numarRoti: Int
    private(set) var motorPornit: Bool = false
    
    private var litriBenzina: Int = 5 {
        didSet {
            if litriBenzina < 0 {
                litriBenzina = 0
                
                semnalRezervorGol()
                opresteMotorul()
            }
        }
    }
    
    init(nume: String, an: Int, roti: Int, locuri: Int) {
        marca = nume
        anFabricatie = an
        numarRoti = roti
        numarLocuri = locuri
    }
    
    func pornesteMotorul() {
        if litriBenzina > 0, motorPornit == false {
            motorPornit = true
            print(marca, "PORNITA")
        } else {
            semnalRezervorGol()
        }
    }
    
    func opresteMotorul() {
        if motorPornit {
            motorPornit = false
            print(marca, "OPRITA")
        }
    }
    
    func parcurge(distanta: Int) {
        if motorPornit {
            litriBenzina -= distanta
            
            if litriBenzina > 0 {
                print(marca, "a parcurs \(distanta)km")
            }
        }
    }
    
    func verificaRezervor() -> Int {
        return litriBenzina
    }
    
    private func semnalRezervorGol() {
        print(marca, "nu mai are benzina. Alimenteaza!!!")
    }
}

class Masina: Vehicul {
    private(set) var numarUsi: Int

    init(nume: String, an: Int, roti: Int = 4, locuri: Int, usi: Int) {
        numarUsi = usi
        super.init(nume: nume, an: an, roti: roti, locuri: locuri)
    }
}

class Motocicleta: Vehicul {
    private(set) var cric: Bool
    
    init(nume: String, an: Int, roti: Int, locuri: Int, cric: Bool = true) {
        self.cric = cric
        super.init(nume: nume, an: an, roti: roti, locuri: locuri)
    }
}

var daciaLogan = Masina(nume: "Dacia", an: 2006, roti: 4, locuri: 5, usi: 4)
daciaLogan.pornesteMotorul()

daciaLogan.parcurge(distanta: 3)
daciaLogan.opresteMotorul()

daciaLogan.parcurge(distanta: 3)
daciaLogan.pornesteMotorul()

daciaLogan.parcurge(distanta: 5)
daciaLogan.pornesteMotorul()
daciaLogan.pornesteMotorul()

print()

var harleyDavidson = Motocicleta(nume: "HD", an: 1998, roti: 2, locuri: 2, cric: true)
harleyDavidson.pornesteMotorul()

print("HD Benzina in rezervor: ", harleyDavidson.verificaRezervor(), "Litri")
harleyDavidson.parcurge(distanta: 3)
print("HD Benzina in rezervor: ", harleyDavidson.verificaRezervor(), "Litri")

harleyDavidson.opresteMotorul()
